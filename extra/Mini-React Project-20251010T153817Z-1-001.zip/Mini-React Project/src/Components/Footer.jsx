import React from 'react'

function Footer() {
  return (
    <div className='footer'>
        Thank you
            <br/>
        2025 @ copyRights applied
    </div>
  )
}

export default Footer